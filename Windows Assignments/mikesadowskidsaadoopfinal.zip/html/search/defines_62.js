var searchData=
[
  ['backupatrributenum',['BACKUPATRRIBUTENUM',['../_management_8h.html#a63502d8fea277c0d16041adc6ba06025',1,'Management.h']]],
  ['buffersize',['BUFFERSIZE',['../_management_8h.html#ac3146f1e9227301bb4aa518f4d336cee',1,'Management.h']]]
];
