var searchData=
[
  ['getassistantcoach',['GetAssistantCoach',['../class_management.html#a4f35b2aa96601b31e78aaf153300b41d',1,'Management']]],
  ['getbackups',['GetBackups',['../class_team.html#a5b802edf160b74d7428d3ee744d847fb',1,'Team']]],
  ['getheadcoach',['GetHeadCoach',['../class_management.html#a6c6b73df06dc1c04f24d1c5acf94cad4',1,'Management']]],
  ['getstarters',['GetStarters',['../class_team.html#a18cb95e82e37488b41d3dd001431e8ec',1,'Team']]],
  ['getteamname',['GetTeamName',['../class_management.html#ad2d09a9d74ff2e5fbea54efcd76577a0',1,'Management']]]
];
