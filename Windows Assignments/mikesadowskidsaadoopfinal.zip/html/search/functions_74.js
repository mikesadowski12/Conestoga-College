var searchData=
[
  ['team',['Team',['../class_team.html#a5c50ce3e6092301c0fa990d924b3827f',1,'Team']]]
];
