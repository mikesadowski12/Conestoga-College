var searchData=
[
  ['headcoach',['headCoach',['../class_management.html#aaec7a4d4d85085cc58237f23b29648bc',1,'Management']]]
];
