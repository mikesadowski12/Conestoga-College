var searchData=
[
  ['maxbackups',['MAXBACKUPS',['../_management_8h.html#a14d22215d85e80ff360b526bd4025785',1,'Management.h']]],
  ['maxlength',['MAXLENGTH',['../_management_8h.html#a1dbd686f69551b83691025eaae058539',1,'Management.h']]],
  ['maxstarters',['MAXSTARTERS',['../_management_8h.html#a8ad0c96529f809b83cae71c128d9e7af',1,'Management.h']]]
];
