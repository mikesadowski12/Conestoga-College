var searchData=
[
  ['starters',['starters',['../class_team.html#ac3a41d0b7f4013c8643529062bf2c239',1,'Team']]]
];
