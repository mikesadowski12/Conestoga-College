var searchData=
[
  ['savedatabase',['SaveDatabase',['../project_8cpp.html#a16f5efc7244d76f0f6ded1d83ea02f28',1,'project.cpp']]],
  ['searchlinkedlist',['searchLinkedList',['../project_8cpp.html#a070d2678760eb078b2db141059cc86c3',1,'project.cpp']]],
  ['setassistantcoach',['SetAssistantCoach',['../class_management.html#a5d4d5d0bc503032c9c26ce15c62bbec8',1,'Management']]],
  ['setbackups',['SetBackups',['../class_team.html#a74a3662a1280c55934675fa6685c8886',1,'Team']]],
  ['setheadcoach',['SetHeadCoach',['../class_management.html#a678515f513782f5516ac5b1c653a2456',1,'Management']]],
  ['setstarters',['SetStarters',['../class_team.html#af808fa3ac89d09c75019f0119f2a7ee1',1,'Team']]],
  ['setteamname',['SetTeamName',['../class_management.html#af1e575b19ed269369eeef2de5719dec8',1,'Management']]]
];
