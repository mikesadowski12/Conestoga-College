var searchData=
[
  ['_7emanagement',['~Management',['../class_management.html#a5e386c7700d6dcc0c1728be3a551b918',1,'Management']]],
  ['_7eteam',['~Team',['../class_team.html#ad0b24ef1a01a350f03517022070f4d74',1,'Team']]]
];
