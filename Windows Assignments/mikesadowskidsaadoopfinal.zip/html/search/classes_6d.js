var searchData=
[
  ['management',['Management',['../class_management.html',1,'']]]
];
