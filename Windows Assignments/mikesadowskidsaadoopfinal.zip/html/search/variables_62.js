var searchData=
[
  ['backups',['backups',['../class_team.html#ad1ef40efc4c39fe0cc34784b872054f7',1,'Team']]]
];
