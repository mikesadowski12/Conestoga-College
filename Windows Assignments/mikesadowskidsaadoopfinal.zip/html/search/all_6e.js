var searchData=
[
  ['next',['next',['../class_team.html#a1d82260b41ee7610a0e36210825a53ea',1,'Team']]]
];
