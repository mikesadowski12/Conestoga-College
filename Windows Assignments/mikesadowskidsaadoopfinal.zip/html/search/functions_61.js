var searchData=
[
  ['addarbitraryitems',['AddArbitraryItems',['../project_8cpp.html#a3a521d8681faae98646e15995b76761f',1,'project.cpp']]],
  ['addnewnode',['AddNewNode',['../project_8cpp.html#a87f85fb3f21ec36166be409eecffc6aa',1,'project.cpp']]]
];
