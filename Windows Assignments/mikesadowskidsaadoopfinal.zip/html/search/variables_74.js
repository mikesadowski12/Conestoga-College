var searchData=
[
  ['teamname',['teamName',['../class_management.html#a78344be52d9cb5025226b4939e562901',1,'Management']]]
];
