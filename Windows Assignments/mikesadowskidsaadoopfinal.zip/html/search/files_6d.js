var searchData=
[
  ['management_2ecpp',['Management.cpp',['../_management_8cpp.html',1,'']]],
  ['management_2eh',['Management.h',['../_management_8h.html',1,'']]]
];
