var searchData=
[
  ['freqs',['Freqs',['../struct_freqs.html',1,'']]]
];
